using UnityEngine;

public class TestItem : MonoBehaviour, IInteractable
{
    private ISelectionResponse selectionResponse;

    
    private void Awake()
    {
        selectionResponse = GetComponent<ISelectionResponse>();
    }

    public void Select()
    {
        Debug.Log("Selected: " + this.gameObject.name);
        selectionResponse?.OnSelect();
    }

    public void Deselect()
    {
        Debug.Log("Deselected: " + this.gameObject.name);
        selectionResponse?.OnDeselect();
    }

    public void Interact(PlayerController player)
    {
        Debug.Log("Interacted with: " + this.gameObject.name);
        Destroy(this.gameObject);
    }
}
