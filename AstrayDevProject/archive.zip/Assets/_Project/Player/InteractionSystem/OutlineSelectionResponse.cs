using UnityEngine;

public class OutlineSelectionResponse : MonoBehaviour, ISelectionResponse
{
    [SerializeField] private Material outlineMaterial;
    private Renderer thisRenderer;
    private Material defaultMaterial;


    private void Awake()
    {
        thisRenderer = GetComponentInChildren<Renderer>();
        defaultMaterial = thisRenderer.material;
    }

    public void OnSelect() => thisRenderer.material = outlineMaterial;

    public void OnDeselect() => thisRenderer.material = defaultMaterial;

}
