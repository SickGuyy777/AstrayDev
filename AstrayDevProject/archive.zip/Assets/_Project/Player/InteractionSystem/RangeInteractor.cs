using UnityEngine;

public class RangeInteractor : MonoBehaviour
{
    [SerializeField] private float range = 2f;
    
    private IInteractable selectedInteractable;
    private GameObject selectedInteractableObject;

    
    private void Update()
    {
        GetSelectedInteractable();
    }

    public void Interact(PlayerController player)
    {
        selectedInteractable?.Interact(player);
    }
    
    private void GetSelectedInteractable()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, range);
        IInteractable interactable = GetClosestInteractable(colliders, out GameObject interactableObject);

        if (selectedInteractable != interactable)
        {
            if (selectedInteractableObject == null)
                selectedInteractable = null;
            
            selectedInteractable?.Deselect();
            selectedInteractable = interactable;
            selectedInteractableObject = interactableObject;
            interactable?.Select();
        }
    }

    private IInteractable GetClosestInteractable(Collider2D[] colliders, out GameObject obj)
    {
        IInteractable closestInteractable = null;
        GameObject closestInteractableObject = null;
        float closestDistance = float.MaxValue;
        
        foreach (Collider2D col in colliders)
        {
            float distance = Vector2.Distance(col.transform.position, transform.position);
            bool withinRange = distance <= range;
            
            if(!withinRange)
                continue;

            IInteractable interactable = col.GetComponent<IInteractable>();
            
            if (interactable != null && distance < closestDistance)
            {
                closestInteractableObject = col.gameObject;
                closestInteractable = interactable;
                closestDistance = distance;
            }
        }

        obj = closestInteractableObject;
        return closestInteractable;
    }
}
