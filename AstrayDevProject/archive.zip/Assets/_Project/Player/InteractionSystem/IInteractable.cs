
public interface IInteractable
{
    void Select();
    void Deselect();
    void Interact(PlayerController player);
}
