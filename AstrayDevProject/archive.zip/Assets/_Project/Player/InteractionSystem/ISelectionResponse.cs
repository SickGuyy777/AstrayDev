
public interface ISelectionResponse
{
    void OnSelect();

    void OnDeselect();
}
