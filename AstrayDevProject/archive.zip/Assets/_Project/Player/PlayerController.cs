using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Movement movement;
    private RangeInteractor interactor;
    private Vector2 mousePos => Camera.main.ScreenToWorldPoint(Input.mousePosition);

    
    private void Awake()
    {
        movement = GetComponent<Movement>();
        interactor = GetComponent<RangeInteractor>();
    }

    private void Update()
    {
        if(PlayerInput.InteractKeyDown)
            interactor.Interact(this);
    }

    private void FixedUpdate()
    {
        UpdateMovement(Time.fixedDeltaTime);
    }
    
    private void UpdateMovement(float deltaTime)
    {
        Vector2 mouseDirection = (mousePos - (Vector2)transform.position).normalized;

        movement.Move(PlayerInput.MovementDirection, deltaTime);
        movement.Look(mouseDirection);
    }
}