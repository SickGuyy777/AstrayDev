using System;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Movement : MonoBehaviour
{
    [Header("Movement")] 
    [SerializeField] private float maxSpeed = 5;

    [SerializeField] private float accleration = 7;
    [SerializeField] private float deceleration = 7;
    
    private Rigidbody2D rb;
    private Animator animator;
    private Vector2 velocity;

    
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        rb.velocity = velocity;

        PlayMovingAnimation();
    }

    private void PlayMovingAnimation()
    {
        bool moving = velocity.magnitude > .1f;
        animator.SetBool("Moving", moving);
    }

    public void Move(Vector2 direction, float deltaTime)
    {
        direction.Normalize();
        
        bool moving = direction != Vector2.zero;
        Vector2 target = moving ? direction * maxSpeed : Vector2.zero;
        float accelerationType = moving ? accleration : deceleration;

        velocity = Vector2.Lerp(velocity, target, accelerationType * deltaTime);
    }

    public void Look(Vector2 direction)
    {
        float angle  = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0, 0, angle);
    }
}
