using UnityEngine;

public class TestInteractable : Interactable {

    public override void Interact()
    {

        Debug.Log("Test Interaction done");

    }

}